#!/bin/bash

# Personal Finance Tracker - Single Production Deployment Script
# Complete deployment for finance.zaihash.xyz with comprehensive fix capabilities
# Includes port conflict resolution and all management features

set -e

# Configuration
DOMAIN="finance.zaihash.xyz"
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
DB_NAME="personal_finance_db"
DB_USER="finance_user"
DB_PASSWORD="finance123"
APP_PORT=3001

# Color output functions
print_status() { echo -e "\033[1;34m[INFO]\033[0m $1"; }
print_success() { echo -e "\033[1;32m[SUCCESS]\033[0m $1"; }
print_warning() { echo -e "\033[1;33m[WARNING]\033[0m $1"; }
print_error() { echo -e "\033[1;31m[ERROR]\033[0m $1"; }

# Check if running as management command
if [ "$1" = "status" ] || [ "$1" = "logs" ] || [ "$1" = "restart" ] || [ "$1" = "fix" ] || [ "$1" = "ssl" ] || [ "$1" = "backup" ] || [ "$1" = "update" ]; then
    case "$1" in
        status)
            echo "=== APPLICATION STATUS ==="
            pm2 status
            echo ""
            echo "=== NGINX STATUS ==="
            sudo systemctl status nginx --no-pager -l
            echo ""
            echo "=== DATABASE STATUS ==="
            sudo systemctl status postgresql --no-pager -l
            echo ""
            echo "=== PORT USAGE ==="
            sudo netstat -tlnp | grep -E ":(80|443|3001|3002|5432)" || echo "No conflicts detected"
            ;;
        logs)
            echo "=== APPLICATION LOGS ==="
            pm2 logs $APP_NAME --lines 20
            ;;
        restart)
            cd $APP_DIR
            pm2 restart $APP_NAME
            ;;
        fix)
            echo "=== COMPREHENSIVE APPLICATION FIX ==="
            cd $APP_DIR
            
            # Show current error logs
            echo "=== Current Error Logs ==="
            pm2 logs $APP_NAME --lines 10 2>/dev/null || echo "No logs available"
            echo ""
            
            # Stop all processes
            print_status "Stopping all processes..."
            pm2 delete $APP_NAME 2>/dev/null || true
            sudo pkill -f "node.*dist" 2>/dev/null || true
            
            # Create fresh environment file with correct port
            print_status "Creating environment file with PORT=3001..."
            cat > .env << EOF
DATABASE_URL=postgresql://finance_user:finance123@localhost:5432/personal_finance_db
SESSION_SECRET=finance-secret-$(date +%s)
NODE_ENV=production
PORT=3001
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=finance123
PGDATABASE=personal_finance_db
EOF
            
            # Clean rebuild with TypeScript compilation
            print_status "Rebuilding application with correct port..."
            rm -rf node_modules dist .next 2>/dev/null || true
            npm install
            print_status "Building application..."
            npm run build
            
            # Verify build succeeded
            if [ ! -f "dist/index.js" ]; then
                print_error "Build failed - checking for TypeScript errors..."
                npm run build
                exit 1
            fi
            print_success "Build completed successfully"
            
            # Reset database if needed
            print_status "Checking database..."
            if ! psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
                print_status "Resetting database..."
                sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH ENCRYPTED PASSWORD 'finance123';
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
ALTER USER finance_user CREATEDB;
\q
EOF
                export DATABASE_URL="postgresql://finance_user:finance123@localhost:5432/personal_finance_db"
                npm run db:push
            fi
            
            # Test manual start
            print_status "Testing manual start..."
            source .env
            timeout 10s node dist/index.js &
            sleep 5
            if sudo netstat -tlnp | grep -q ":3001"; then
                print_success "Manual start successful - application uses port 3001"
                pkill -f "node dist/index.js"
            else
                print_error "Manual start failed - showing error:"
                timeout 5s node dist/index.js
                exit 1
            fi
            
            # Start with PM2
            print_status "Starting with PM2..."
            pm2 start ecosystem.config.cjs
            pm2 save
            sleep 5
            
            # Verify success
            if pm2 list | grep -q "$APP_NAME.*online"; then
                print_success "Application fixed and running"
                if curl -s http://localhost:3001 >/dev/null 2>&1; then
                    print_success "Web server responding on port 3001"
                    print_success "App is live at http://finance.zaihash.xyz"
                else
                    print_warning "Web server not responding yet - may need more time"
                fi
            else
                print_error "Application still failing"
                pm2 logs $APP_NAME --lines 5
            fi
            ;;
        ssl)
            print_status "Setting up SSL manually..."
            sudo apt update && sudo apt install -y certbot python3-certbot-nginx
            sudo certbot --nginx -d $DOMAIN
            sudo systemctl reload nginx
            print_success "SSL setup completed"
            ;;
        backup)
            BACKUP_DIR="/var/backups/personal-finance-tracker"
            sudo mkdir -p $BACKUP_DIR
            BACKUP_FILE="$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).sql"
            sudo -u postgres pg_dump personal_finance_db > $BACKUP_FILE
            print_success "Database backed up to $BACKUP_FILE"
            ;;
        update)
            cd $APP_DIR
            git pull origin main
            npm install
            npm run build
            pm2 restart $APP_NAME
            print_success "Application updated"
            ;;
    esac
    exit 0
fi

# Main deployment script starts here
print_status "Starting Personal Finance Tracker deployment..."

# Check if already deployed
if [ -d "$APP_DIR" ] && [ "$1" != "--force" ]; then
    print_warning "Application already exists. Use './deploy.sh fix' to fix issues or './deploy.sh --force' to redeploy"
    exit 1
fi

# System requirements check
print_status "Checking system requirements..."
if ! command -v node >/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

if ! command -v nginx >/dev/null; then
    print_status "Installing Nginx..."
    sudo apt update && sudo apt install -y nginx
fi

if ! command -v psql >/dev/null; then
    print_status "Installing PostgreSQL..."
    sudo apt update && sudo apt install -y postgresql postgresql-contrib
fi

if ! command -v pm2 >/dev/null; then
    print_status "Installing PM2..."
    sudo npm install -g pm2
fi

# Check for port conflicts
if sudo netstat -tlnp | grep -q ":3001"; then
    APP_PORT=3002
    print_warning "Port 3001 in use, switching to 3002"
fi

# Create application directory
print_status "Setting up application directory..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR
cd $APP_DIR

# Clone or copy application files
if [ ! -f "package.json" ]; then
    print_status "Copying application files..."
    # Copy files from current directory to app directory
    rsync -av --exclude node_modules --exclude dist --exclude .git $(dirname $0)/ .
fi

# Database setup
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE USER $DB_USER WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
CREATE DATABASE $DB_NAME OWNER $DB_USER;
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
ALTER USER $DB_USER CREATEDB;
\q
EOF

# Environment configuration
print_status "Creating environment configuration..."
cat > .env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=finance-secret-$(date +%s)
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
EOF

# Install dependencies and build
print_status "Installing dependencies and building application..."
npm install
npm run build

# Verify build
if [ ! -f "dist/index.js" ]; then
    print_error "Build failed - application cannot start"
    exit 1
fi

# Database schema setup
print_status "Setting up database schema..."
export DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME"
npm run db:push

# PM2 ecosystem configuration
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: '$APP_NAME',
    script: 'node',
    args: 'dist/index.js',
    cwd: '$APP_DIR',
    env_file: '.env',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    min_uptime: '10s',
    max_restarts: 5,
    restart_delay: 5000,
    kill_timeout: 5000,
    error_file: '/var/log/personal-finance-tracker/error.log',
    out_file: '/var/log/personal-finance-tracker/out.log',
    log_file: '/var/log/personal-finance-tracker/combined.log'
  }]
};
EOF

# Create log directory
sudo mkdir -p /var/log/personal-finance-tracker
sudo chown $USER:$USER /var/log/personal-finance-tracker

# Nginx configuration
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/$APP_NAME << EOF
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete $APP_NAME 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Security configuration
print_status "Configuring security..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Verify deployment
print_status "Verifying deployment..."
sleep 5

if pm2 list | grep -q "$APP_NAME.*online"; then
    print_success "Application is running successfully"
else
    print_error "Application failed to start"
    pm2 logs $APP_NAME --lines 10
    exit 1
fi

# Test web response
if curl -f -s http://localhost:$APP_PORT >/dev/null 2>&1; then
    print_success "Web server responding correctly on port $APP_PORT"
else
    print_warning "Web server test failed - may need time to start"
fi

# Final status report
echo ""
echo "========================================"
echo "DEPLOYMENT COMPLETED SUCCESSFULLY"
echo "========================================"
echo ""
echo "Application Details:"
echo "  URL: http://$DOMAIN"
echo "  Internal Port: $APP_PORT"
echo "  Directory: $APP_DIR"
echo "  Database: $DB_NAME"
echo ""
echo "Management Commands:"
echo "  ./deploy.sh status    - Check status"
echo "  ./deploy.sh logs      - View logs"
echo "  ./deploy.sh restart   - Restart app"
echo "  ./deploy.sh fix       - Fix any issues"
echo "  ./deploy.sh ssl       - Setup SSL"
echo "  ./deploy.sh update    - Update app"
echo "  ./deploy.sh backup    - Backup data"
echo ""
echo "Next Steps:"
echo "1. Your finance app is live at: http://$DOMAIN"
echo "2. Setup SSL: ./deploy.sh ssl"
echo ""
echo "Your Personal Finance Tracker is ready!"