#!/bin/bash

# Personal Finance Tracker - Complete Deployment Script
# Domain: finance.zaihash.xyz
# Handles installation, fixes, and deployment in one script

set -e

DOMAIN="finance.zaihash.xyz"
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
LOG_DIR="/var/log/$APP_NAME"
DB_PASSWORD="finance123"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check root
if [[ $EUID -eq 0 ]]; then
   print_error "Run as regular user with sudo privileges"
   exit 1
fi

# Stop all existing processes
print_status "Stopping existing processes..."
pm2 delete all 2>/dev/null || true
sudo pkill -f "personal-finance-tracker" 2>/dev/null || true
sudo pkill -f "node.*dist" 2>/dev/null || true

# Detect available port
if command -v ss >/dev/null 2>&1 && sudo ss -tlnp | grep -q ":3001 "; then
    APP_PORT=3002
else
    APP_PORT=3001
fi
print_status "Using port $APP_PORT"

# System packages
print_status "Installing system packages..."
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget gnupg2 postgresql postgresql-contrib nginx

# Node.js installation
if ! command -v node >/dev/null 2>&1; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    print_status "Node.js already installed"
fi

# PM2 installation
if ! command -v pm2 >/dev/null 2>&1; then
    print_status "Installing PM2..."
    sudo npm install -g pm2
else
    print_status "PM2 already installed"
fi

# Database setup with clean reset
print_status "Setting up database..."
sudo -u postgres psql << EOF || true
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
ALTER USER finance_user CREATEDB;
\q
EOF

# Create application directories
print_status "Creating directories..."
sudo mkdir -p $APP_DIR $LOG_DIR
sudo chown $USER:$USER $APP_DIR $LOG_DIR

# Copy application files
print_status "Copying application files..."
cp -r * $APP_DIR/ 2>/dev/null || true
cd $APP_DIR

# Create environment configuration
print_status "Creating environment..."
cat > .env << EOF
DATABASE_URL=postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db
SESSION_SECRET=finance-secret-$(date +%s)
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
EOF

# Clean install and build
print_status "Installing dependencies..."
rm -rf node_modules dist 2>/dev/null || true
npm install

print_status "Building application..."
npm run build

# Verify build success
if [ ! -f "dist/index.js" ]; then
    print_error "Build failed - dist/index.js not created"
    exit 1
fi

# Setup database schema
print_status "Setting up database schema..."
export DATABASE_URL="postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db"
export PGHOST=localhost
export PGPORT=5432
export PGUSER=finance_user
export PGPASSWORD="$DB_PASSWORD"
export PGDATABASE=personal_finance_db

npm run db:push

# Test database connection
if ! psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection test failed"
    exit 1
fi

# Create PM2 ecosystem configuration
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: '$APP_NAME',
    script: 'node',
    args: 'dist/index.js',
    cwd: '$APP_DIR',
    env_file: '.env',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    min_uptime: '10s',
    max_restarts: 5,
    error_file: '$LOG_DIR/error.log',
    out_file: '$LOG_DIR/out.log',
    log_file: '$LOG_DIR/combined.log'
  }]
};
EOF

# Configure Nginx
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOF
server {
    listen 80;
    server_name $DOMAIN;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

# Enable Nginx site
sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application..."
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 auto-startup
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME

# Configure firewall
print_status "Configuring firewall..."
sudo ufw --force enable
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'

# Create management script
print_status "Creating management tools..."
cat > manage.sh << 'SCRIPT'
#!/bin/bash

APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"

case $1 in
    status)
        echo "=== Application Status ==="
        pm2 status
        echo ""
        echo "=== System Status ==="
        systemctl is-active nginx postgresql
        echo ""
        echo "=== Resources ==="
        free -h | head -2
        df -h / | tail -1
        ;;
    logs)
        pm2 logs $APP_NAME
        ;;
    restart)
        cd $APP_DIR
        pm2 restart $APP_NAME
        ;;
    fix)
        echo "Fixing application..."
        cd $APP_DIR
        
        # Show current error logs
        echo "=== Current Error Logs ==="
        pm2 logs $APP_NAME --lines 10 2>/dev/null || echo "No logs available"
        echo ""
        
        # Stop all processes
        pm2 delete $APP_NAME 2>/dev/null || true
        sudo pkill -f "node.*dist" 2>/dev/null || true
        
        # Verify environment
        if [ ! -f ".env" ]; then
            echo "Creating environment file..."
            cat > .env << EOF
DATABASE_URL=postgresql://finance_user:finance123@localhost:5432/personal_finance_db
SESSION_SECRET=finance-secret-\$(date +%s)
NODE_ENV=production
PORT=3001
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=finance123
PGDATABASE=personal_finance_db
EOF
        fi
        
        # Clean rebuild
        echo "Rebuilding application..."
        rm -rf node_modules dist 2>/dev/null || true
        npm install
        npm run build
        
        # Reset database if needed
        echo "Checking database..."
        if ! psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
            echo "Resetting database..."
            sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH ENCRYPTED PASSWORD 'finance123';
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
ALTER USER finance_user CREATEDB;
\q
EOF
            export DATABASE_URL="postgresql://finance_user:finance123@localhost:5432/personal_finance_db"
            npm run db:push
        fi
        
        # Test manual start
        echo "Testing manual start..."
        source .env
        timeout 10s node dist/index.js &
        sleep 5
        if sudo netstat -tlnp | grep -q ":3001"; then
            echo "Manual start successful"
            pkill -f "node dist/index.js"
        else
            echo "Manual start failed - showing error:"
            timeout 5s node dist/index.js
            exit 1
        fi
        
        # Start with PM2
        echo "Starting with PM2..."
        pm2 start ecosystem.config.cjs
        pm2 save
        sleep 5
        
        # Verify success
        if pm2 list | grep -q "$APP_NAME.*online"; then
            echo "✅ Application fixed and running"
            if curl -s http://localhost:3001 >/dev/null 2>&1; then
                echo "✅ Web server responding"
                echo "SUCCESS: App is live at http://finance.zaihash.xyz"
            else
                echo "⚠️ Web server not responding yet"
            fi
        else
            echo "❌ Application still failing"
            pm2 logs $APP_NAME --lines 5
        fi
        ;;
    ssl)
        echo "Setting up SSL..."
        sudo apt install -y certbot python3-certbot-nginx
        sudo certbot --nginx -d finance.zaihash.xyz
        ;;
    update)
        echo "Updating application..."
        cd $APP_DIR
        npm install
        npm run build
        npm run db:push
        pm2 restart $APP_NAME
        echo "Update completed"
        ;;
    backup)
        echo "Creating database backup..."
        sudo -u postgres pg_dump personal_finance_db > "backup-$(date +%Y%m%d-%H%M%S).sql"
        echo "Backup created successfully"
        ;;
    *)
        echo "Personal Finance Tracker Management"
        echo "Usage: $0 {status|logs|restart|fix|ssl|update|backup}"
        echo ""
        echo "Commands:"
        echo "  status  - Show application and system status"
        echo "  logs    - View application logs"
        echo "  restart - Restart application"
        echo "  fix     - Fix build and restart issues"
        echo "  ssl     - Setup SSL certificate"
        echo "  update  - Update and rebuild application"
        echo "  backup  - Create database backup"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Verify deployment
print_status "Verifying deployment..."
sleep 5

if pm2 list | grep -q "$APP_NAME.*online"; then
    print_status "Application is running successfully"
else
    print_error "Application failed to start"
    pm2 logs $APP_NAME --lines 10
    exit 1
fi

# Test web response
if curl -f -s http://localhost:$APP_PORT >/dev/null 2>&1; then
    print_status "Web server responding correctly"
else
    print_warning "Web server test failed - may need time to start"
fi

# Final status report
echo ""
echo "========================================"
echo "DEPLOYMENT COMPLETED SUCCESSFULLY"
echo "========================================"
echo ""
echo "Application Details:"
echo "  URL: http://$DOMAIN"
echo "  Internal Port: $APP_PORT"
echo "  Directory: $APP_DIR"
echo "  Database: personal_finance_db"
echo ""
echo "Management Commands:"
echo "  ./manage.sh status    - Check status"
echo "  ./manage.sh logs      - View logs"
echo "  ./manage.sh restart   - Restart app"
echo "  ./manage.sh fix       - Fix issues"
echo "  ./manage.sh ssl       - Setup SSL"
echo "  ./manage.sh update    - Update app"
echo "  ./manage.sh backup    - Backup data"
echo ""
echo "Next Steps:"
echo "1. Your finance app is live at: http://$DOMAIN"
echo "2. Setup SSL: ./manage.sh ssl"
echo ""
echo "Your Personal Finance Tracker is ready!"
echo ""