# Deployment Summary for finance.zaihash.xyz

## ✅ Problem Solved: No Port Conflicts

Your main concern about port conflicts has been addressed:

### Port Assignment Strategy
- **Main Site (zaihash.xyz)**: Continues on existing ports (80/443)
- **Finance App**: Runs internally on port 3001 (or 3002 if 3001 is busy)
- **Nginx Routing**: Uses virtual hosts to route traffic based on domain name

### How It Works
1. **Both domains share ports 80/443** - Nginx listens on these ports
2. **Domain-based routing** - Nginx checks the domain name in requests:
   - `zaihash.xyz` → Your existing site
   - `finance.zaihash.xyz` → Finance app (internal port 3001)
3. **No interference** - Your main site continues working exactly as before

## Quick Deployment Steps

### 1. Add DNS Record
```
Type: A
Name: finance
Value: YOUR_SERVER_IP
```

### 2. Run Deployment Script
```bash
# Upload files to your server
scp -r * user@your-server:/home/user/finance-app/

# SSH to your server
ssh user@your-server

# Navigate to the app directory
cd finance-app

# Run the deployment script
chmod +x deploy-subdomain.sh
./deploy-subdomain.sh
```

### 3. The Script Automatically:
- ✅ Checks for port conflicts (uses 3002 if 3001 is busy)
- ✅ Installs Node.js, PostgreSQL, PM2 without affecting existing setup
- ✅ Creates new Nginx virtual host for subdomain only
- ✅ Sets up SSL certificate for finance.zaihash.xyz
- ✅ Starts the finance app on separate port
- ✅ Creates management commands

## What Gets Installed
- Node.js 20 (if not already installed)
- PostgreSQL database (new database: `personal_finance_db`)
- PM2 process manager
- SSL certificate for subdomain only

## Your Main Site Security
- ✅ Existing Nginx configuration preserved
- ✅ Main site SSL certificates untouched
- ✅ No changes to existing database
- ✅ Separate user and database for finance app
- ✅ Firewall rules only add necessary ports

## After Deployment
Your setup will look like this:
```
Port 80/443 (Nginx)
├── zaihash.xyz → Your existing site
└── finance.zaihash.xyz → Finance app (port 3001)

Database
├── Your existing databases (untouched)
└── personal_finance_db (new, separate)
```

## Management Commands
```bash
# Check everything is running
./manage.sh status

# View finance app logs
./manage.sh logs

# Restart just the finance app
./manage.sh restart

# Update finance app
./manage.sh update

# Backup finance database only
./manage.sh backup
```

## Zero Impact Guarantee
- Your main site continues running unchanged
- All existing configurations preserved
- Separate database and user for finance app
- Can be completely removed without affecting main site

Ready to deploy? The script handles everything automatically!