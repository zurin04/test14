import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Calendar, Plus, Edit, Trash2, Tag, FileText, Calendar as CalendarIcon } from "lucide-react";
import { format } from "date-fns";

const NOTE_CATEGORIES = [
  "Personal",
  "Work", 
  "Finance",
  "Health",
  "Goals",
  "Ideas",
  "Travel",
  "Learning",
  "Other"
];

interface Note {
  id: number;
  title: string;
  content: string;
  category: string;
  noteType: string;
  noteDate: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export default function NotesSidebar() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const { data: notes = [] } = useQuery({
    queryKey: ["/api/notes"],
  });

  const noteForm = useForm({
    defaultValues: {
      title: "",
      content: "",
      category: "Personal",
      noteType: "note",
      noteDate: format(new Date(), "yyyy-MM-dd"),
      tags: "",
    },
  });

  const createNoteMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/notes", data),
    onSuccess: () => {
      toast({ title: "Note created successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      setShowNoteDialog(false);
      noteForm.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to create note", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      apiRequest("PUT", `/api/notes/${id}`, data),
    onSuccess: () => {
      toast({ title: "Note updated successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      setShowNoteDialog(false);
      setEditingNote(null);
      noteForm.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to update note", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/notes/${id}`, {}),
    onSuccess: () => {
      toast({ title: "Note deleted successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to delete note", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const handleSubmit = (data: any) => {
    const noteData = {
      ...data,
      tags: data.tags ? data.tags.split(",").map((tag: string) => tag.trim()) : [],
    };

    if (editingNote) {
      updateNoteMutation.mutate({ id: editingNote.id, data: noteData });
    } else {
      createNoteMutation.mutate(noteData);
    }
  };

  const handleEdit = (note: Note) => {
    setEditingNote(note);
    noteForm.reset({
      title: note.title,
      content: note.content,
      category: note.category,
      noteType: note.noteType,
      noteDate: note.noteDate,
      tags: note.tags?.join(", ") || "",
    });
    setShowNoteDialog(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this note?")) {
      deleteNoteMutation.mutate(id);
    }
  };

  const createDailyDiary = () => {
    const today = format(new Date(), "yyyy-MM-dd");
    noteForm.reset({
      title: `Daily Diary - ${format(new Date(), "MMMM d, yyyy")}`,
      content: "",
      category: "Personal",
      noteType: "diary",
      noteDate: today,
      tags: "diary",
    });
    setEditingNote(null);
    setShowNoteDialog(true);
  };

  const filteredNotes = notes.filter((note: Note) => {
    const matchesCategory = selectedCategory === "all" || note.category === selectedCategory;
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         note.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const todaysDiary = notes.find((note: Note) => 
    note.noteType === "diary" && note.noteDate === format(new Date(), "yyyy-MM-dd")
  );

  return (
    <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Notes & Diary
          </h2>
        </div>
        
        <div className="flex gap-2 mb-4">
          <Dialog open={showNoteDialog} onOpenChange={setShowNoteDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="flex-1">
                <Plus className="w-4 h-4 mr-1" />
                Note
              </Button>
            </DialogTrigger>
          </Dialog>
          
          <Button size="sm" variant="outline" onClick={createDailyDiary} className="flex-1">
            <Calendar className="w-4 h-4 mr-1" />
            Diary
          </Button>
        </div>

        {/* Search */}
        <Input
          placeholder="Search notes..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="mb-3"
        />

        {/* Category Filter */}
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {NOTE_CATEGORIES.map((category) => (
              <SelectItem key={category} value={category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Today's Diary Quick Access */}
      {todaysDiary && (
        <div className="p-4 border-b border-gray-200 bg-blue-50">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-blue-900">Today's Diary</h3>
            <Button size="sm" variant="ghost" onClick={() => handleEdit(todaysDiary)}>
              <Edit className="w-3 h-3" />
            </Button>
          </div>
          <p className="text-xs text-blue-700 line-clamp-2">{todaysDiary.content}</p>
        </div>
      )}

      {/* Notes List */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-3">
          {filteredNotes.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No notes found</p>
              <p className="text-sm text-gray-500">Create your first note or diary entry</p>
            </div>
          ) : (
            filteredNotes.map((note: Note) => (
              <Card key={note.id} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-sm font-medium line-clamp-1">
                        {note.title}
                      </CardTitle>
                      <CardDescription className="text-xs">
                        {format(new Date(note.noteDate), "MMM d, yyyy")}
                      </CardDescription>
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 p-0"
                        onClick={() => handleEdit(note)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                        onClick={() => handleDelete(note.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-xs text-gray-600 line-clamp-2 mb-2">
                    {note.content}
                  </p>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs">
                      {note.category}
                    </Badge>
                    {note.noteType === "diary" && (
                      <Badge variant="outline" className="text-xs">
                        <CalendarIcon className="w-3 h-3 mr-1" />
                        Diary
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>

      {/* Note Dialog */}
      <Dialog open={showNoteDialog} onOpenChange={setShowNoteDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingNote ? "Edit Note" : "Create New Note"}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={noteForm.handleSubmit(handleSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                {...noteForm.register("title")}
                placeholder="Enter note title"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <Select
                  value={noteForm.watch("category")}
                  onValueChange={(value) => noteForm.setValue("category", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {NOTE_CATEGORIES.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="noteDate">Date</Label>
                <Input
                  id="noteDate"
                  type="date"
                  {...noteForm.register("noteDate")}
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="noteType">Type</Label>
              <Select
                value={noteForm.watch("noteType")}
                onValueChange={(value) => noteForm.setValue("noteType", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="note">Note</SelectItem>
                  <SelectItem value="diary">Diary</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                {...noteForm.register("content")}
                placeholder="Write your note content here..."
                rows={8}
                required
              />
            </div>

            <div>
              <Label htmlFor="tags">Tags (comma-separated)</Label>
              <Input
                id="tags"
                {...noteForm.register("tags")}
                placeholder="personal, work, important"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setShowNoteDialog(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createNoteMutation.isPending || updateNoteMutation.isPending}
              >
                {createNoteMutation.isPending || updateNoteMutation.isPending 
                  ? "Saving..." 
                  : editingNote ? "Update Note" : "Create Note"
                }
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}