import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek, isSameMonth, isSameDay } from "date-fns";
import CalendarDateDetails from "./calendar-date-details";

export default function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showDateDetails, setShowDateDetails] = useState(false);
  
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  
  const calendarDays = eachDayOfInterval({
    start: calendarStart,
    end: calendarEnd,
  });

  const { data: income } = useQuery({
    queryKey: ["/api/income"],
    queryFn: () => fetch("/api/income").then(res => res.json()),
  });

  const { data: expenses } = useQuery({
    queryKey: ["/api/expenses"],
    queryFn: () => fetch("/api/expenses").then(res => res.json()),
  });

  const { data: tasks } = useQuery({
    queryKey: ["/api/tasks"],
    queryFn: () => fetch("/api/tasks").then(res => res.json()),
  });

  const { data: bills } = useQuery({
    queryKey: ["/api/bills"],
    queryFn: () => fetch("/api/bills").then(res => res.json()),
  });

  const { data: notes } = useQuery({
    queryKey: ["/api/notes"],
    queryFn: () => fetch("/api/notes").then(res => res.json()),
  });

  const getEventsForDate = (date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    const events = [];

    // Check for income
    if (income?.some((item: any) => item.date === dateStr)) {
      events.push("income");
    }

    // Check for expenses
    if (expenses?.some((item: any) => item.date === dateStr)) {
      events.push("expense");
    }

    // Check for tasks
    if (tasks?.some((item: any) => item.dueDate === dateStr)) {
      events.push("task");
    }

    // Check for bills
    if (bills?.some((item: any) => item.dueDate === dateStr)) {
      events.push("bill");
    }

    // Check for notes
    if (notes?.some((note: any) => note.noteDate === dateStr && note.noteType === "note")) {
      events.push("note");
    }

    // Check for diary entries
    if (notes?.some((note: any) => note.noteDate === dateStr && note.noteType === "diary")) {
      events.push("diary");
    }

    return events;
  };

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setShowDateDetails(true);
  };

  const closeDateDetails = () => {
    setShowDateDetails(false);
    setSelectedDate(null);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Calendar Overview</h2>
          <div className="flex items-center space-x-2">
            <button 
              onClick={previousMonth}
              className="px-3 py-1 text-sm bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-sm font-medium text-gray-900">
              {format(currentDate, "MMMM yyyy")}
            </span>
            <button 
              onClick={nextMonth}
              className="px-3 py-1 text-sm bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        {/* Calendar Header */}
        <div className="grid grid-cols-7 gap-1 mb-4">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
            <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
              {day}
            </div>
          ))}
        </div>
        
        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-1">
          {calendarDays.map((day) => {
            const events = getEventsForDate(day);
            const isToday = isSameDay(day, new Date());
            const isCurrentMonth = isSameMonth(day, currentDate);
            
            return (
              <div key={day.toString()} className="aspect-square p-1">
                <button
                  onClick={() => handleDateClick(day)}
                  className={`w-full h-full flex flex-col p-2 rounded-md transition-colors hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-1 ${
                    isToday ? 'bg-primary-light border-2 border-primary' : 'border border-transparent'
                  } ${events.length > 0 ? 'hover:bg-gray-50' : ''}`}
                >
                  <span className={`text-xs ${isCurrentMonth ? (isToday ? 'text-primary font-medium' : 'text-gray-900') : 'text-gray-400'}`}>
                    {format(day, "d")}
                  </span>
                  <div className="flex-1 mt-1 space-y-1">
                    {events.includes("income") && (
                      <div className="w-2 h-2 bg-success rounded-full"></div>
                    )}
                    {events.includes("expense") && (
                      <div className="w-2 h-2 bg-error rounded-full"></div>
                    )}
                    {events.includes("task") && (
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                    )}
                    {events.includes("bill") && (
                      <div className="w-2 h-2 bg-warning rounded-full"></div>
                    )}
                    {events.includes("note") && (
                      <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                    )}
                    {events.includes("diary") && (
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    )}
                  </div>
                </button>
              </div>
            );
          })}
        </div>
        
        {/* Calendar Legend */}
        <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-success rounded-full"></div>
            <span className="text-xs text-gray-600">Income</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-error rounded-full"></div>
            <span className="text-xs text-gray-600">Expenses</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span className="text-xs text-gray-600">Tasks</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-warning rounded-full"></div>
            <span className="text-xs text-gray-600">Bills</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-indigo-500 rounded-full"></div>
            <span className="text-xs text-gray-600">Notes</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
            <span className="text-xs text-gray-600">Diary</span>
          </div>
        </div>
      </div>

      <CalendarDateDetails 
        isOpen={showDateDetails}
        onClose={closeDateDetails}
        selectedDate={selectedDate}
      />
    </div>
  );
}
