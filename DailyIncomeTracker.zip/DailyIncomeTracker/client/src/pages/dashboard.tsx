import NavigationHeader from "@/components/navigation-header";
import DashboardOverview from "@/components/dashboard-overview";
import CalendarView from "@/components/calendar-view";
import RecentTransactions from "@/components/recent-transactions";
import QuickAddForms from "@/components/quick-add-forms";
import TodaysTasks from "@/components/todays-tasks";
import GoalsProgress from "@/components/goals-progress";
import NotesSidebar from "@/components/notes-sidebar";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Notes Sidebar */}
      <NotesSidebar />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <NavigationHeader />
        
        <div className="flex-1 px-4 sm:px-6 lg:px-8 py-8">
          <DashboardOverview />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <CalendarView />
              <RecentTransactions />
            </div>
            
            <div className="space-y-6">
              <QuickAddForms />
              <TodaysTasks />
              <GoalsProgress />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
