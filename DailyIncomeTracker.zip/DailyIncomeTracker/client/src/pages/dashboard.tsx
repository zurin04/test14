import NavigationHeader from "@/components/navigation-header";
import DashboardOverview from "@/components/dashboard-overview";
import CalendarView from "@/components/calendar-view";
import RecentTransactions from "@/components/recent-transactions";
import QuickAddForms from "@/components/quick-add-forms";
import TodaysTasks from "@/components/todays-tasks";
import GoalsProgress from "@/components/goals-progress";
import NotesSidebar from "@/components/notes-sidebar";

export default function Dashboard() {
  console.log("Dashboard component rendering - timestamp:", new Date().toISOString());
  
  return (
    <>
      <div className="fixed inset-0 bg-gray-50 flex" data-testid="dashboard-container">
        {/* Sidebar */}
        <aside className="w-80 bg-white border-r border-gray-200 flex flex-col">
          <NotesSidebar />
        </aside>
        
        {/* Main Content Area */}
        <main className="flex-1 flex flex-col">
          {/* Header */}
          <header className="flex-shrink-0">
            <NavigationHeader />
          </header>
          
          {/* Dashboard Content */}
          <section className="flex-1 p-6 overflow-y-auto">
            {/* Dashboard Overview Cards */}
            <DashboardOverview />
            
            {/* Main Dashboard Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
              {/* Left Column */}
              <div className="lg:col-span-2 space-y-6">
                <CalendarView />
                <RecentTransactions />
              </div>
              
              {/* Right Column */}
              <div className="space-y-6">
                <QuickAddForms />
                <TodaysTasks />
                <GoalsProgress />
              </div>
            </div>
          </section>
        </main>
      </div>
    </>
  );
}
