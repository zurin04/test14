#!/bin/bash

# Personal Finance Tracker - Complete Deployment Script
# Domain: finance.zaihash.xyz
# Handles installation, build, and deployment in one script

set -e

DOMAIN="finance.zaihash.xyz"
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
LOG_DIR="/var/log/$APP_NAME"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "Run as regular user with sudo privileges, not root."
   exit 1
fi

# Check for port conflicts
print_status "Checking for port conflicts..."
if command -v ss >/dev/null 2>&1; then
    if sudo ss -tlnp | grep -q ":3001 "; then
        print_warning "Port 3001 busy, using port 3002"
        APP_PORT=3002
    else
        APP_PORT=3001
    fi
else
    APP_PORT=3001
fi

print_status "Using port $APP_PORT"

# Stop any existing PM2 processes
print_status "Stopping existing processes..."
pm2 delete $APP_NAME 2>/dev/null || pm2 delete all 2>/dev/null || true

# Update system
print_status "Updating system..."
sudo apt update && sudo apt upgrade -y

# Install required packages
print_status "Installing system packages..."
sudo apt install -y curl wget gnupg2 software-properties-common apt-transport-https ca-certificates lsb-release

# Install Node.js 20
if ! command -v node >/dev/null 2>&1; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    print_status "Node.js already installed"
fi

# Install PostgreSQL
if ! command -v psql >/dev/null 2>&1; then
    print_status "Installing PostgreSQL..."
    sudo apt install -y postgresql postgresql-contrib
else
    print_status "PostgreSQL already installed"
fi

# Install Nginx
if ! command -v nginx >/dev/null 2>&1; then
    print_status "Installing Nginx..."
    sudo apt install -y nginx
else
    print_status "Nginx already installed"
fi

# Install PM2
if ! command -v pm2 >/dev/null 2>&1; then
    print_status "Installing PM2..."
    sudo npm install -g pm2
else
    print_status "PM2 already installed"
fi

# Setup PostgreSQL database
print_status "Setting up database..."
DB_PASSWORD=$(openssl rand -base64 32)
sudo -u postgres psql << EOF || print_warning "Database might exist, continuing..."
CREATE USER finance_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
ALTER USER finance_user CREATEDB;
\q
EOF

# Create directories
print_status "Creating directories..."
sudo mkdir -p $APP_DIR $LOG_DIR
sudo chown $USER:$USER $APP_DIR $LOG_DIR

# Copy files
print_status "Copying application files..."
cp -r * $APP_DIR/ 2>/dev/null || true
cd $APP_DIR

# Create environment file
print_status "Creating environment..."
cat > .env << EOF
DATABASE_URL=postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db
SESSION_SECRET=$(openssl rand -base64 32)
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
EOF

# Install dependencies and build
print_status "Installing dependencies..."
npm install

print_status "Building application..."
npm run build

# Verify build
if [ ! -f "dist/index.js" ]; then
    print_error "Build failed - dist/index.js missing"
    exit 1
fi

# Setup database schema
print_status "Setting up database schema..."
npm run db:push

# Create PM2 config
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [
    {
      name: '$APP_NAME',
      script: 'npm',
      args: 'run start',
      cwd: '$APP_DIR',
      env: {
        NODE_ENV: 'production',
        PORT: $APP_PORT
      },
      env_file: '.env',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      error_file: '$LOG_DIR/error.log',
      out_file: '$LOG_DIR/out.log',
      log_file: '$LOG_DIR/combined.log',
      time: true
    }
  ]
};
EOF

# Configure Nginx
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOF
server {
    listen 80;
    server_name $DOMAIN;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application..."
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Setting up auto-startup..."
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME

# Configure firewall
print_status "Configuring firewall..."
sudo ufw --force enable
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'

# Create management script
print_status "Creating management tools..."
cat > manage.sh << 'SCRIPT'
#!/bin/bash

APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"

case $1 in
    status)
        echo "=== Application Status ==="
        pm2 status
        echo "=== System Resources ==="
        free -h
        df -h
        echo "=== Services ==="
        systemctl is-active nginx postgresql
        ;;
    logs)
        pm2 logs $APP_NAME
        ;;
    restart)
        pm2 restart $APP_NAME
        ;;
    update)
        echo "Updating application..."
        cd $APP_DIR
        npm install
        npm run build
        npm run db:push
        pm2 restart $APP_NAME
        echo "Updated successfully!"
        ;;
    backup)
        echo "Creating backup..."
        sudo -u postgres pg_dump personal_finance_db > "backup-$(date +%Y%m%d-%H%M%S).sql"
        echo "Backup created!"
        ;;
    fix)
        echo "Fixing application..."
        cd $APP_DIR
        pm2 delete $APP_NAME 2>/dev/null || true
        npm run build
        pm2 start ecosystem.config.cjs
        pm2 save
        echo "Fixed and restarted!"
        ;;
    *)
        echo "Usage: $0 {status|logs|restart|update|backup|fix}"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Verify deployment
print_status "Verifying deployment..."
sleep 5

if pm2 list | grep -q "$APP_NAME.*online"; then
    print_status "Application running successfully!"
else
    print_error "Application failed to start"
    pm2 logs $APP_NAME --lines 5
    exit 1
fi

# Test web response
if curl -f -s http://localhost:$APP_PORT >/dev/null 2>&1; then
    print_status "Web server responding"
else
    print_warning "Web server not responding on port $APP_PORT"
fi

# Final status
echo ""
echo "================================================="
echo "🎉 Deployment Complete!"
echo "================================================="
echo ""
echo "🌐 URL: http://$DOMAIN"
echo "📱 Port: $APP_PORT"
echo "🔧 Directory: $APP_DIR"
echo ""
echo "Next Steps:"
echo "1. Setup SSL: sudo apt install certbot python3-certbot-nginx"
echo "2. Get certificate: sudo certbot --nginx -d $DOMAIN"
echo ""
echo "Management:"
echo "  ./manage.sh status    - Check status"
echo "  ./manage.sh logs      - View logs"
echo "  ./manage.sh restart   - Restart app"
echo "  ./manage.sh fix       - Fix issues"
echo ""
echo "Your finance app is live at: http://$DOMAIN"
echo ""