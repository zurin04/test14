#!/bin/bash

# Personal Finance Tracker - Complete Production VPS Deployment
# Enhanced one-click deployment for Ubuntu VPS with comprehensive error handling
# 
# Latest Features (July 2025):
# - Profile persistence for email/password and Web3 wallet authentication
# - Enhanced authentication flow with proper query invalidation
# - Fixed frontend caching issues for user data consistency
# - Multi-currency support (USD/PHP) with proper formatting

set -euo pipefail

echo "=========================================="
echo "Personal Finance Tracker - Complete Setup"
echo "=========================================="

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_debug() { echo -e "${BLUE}[DEBUG]${NC} $1"; }

# Global variables
APP_DIR="/var/www/personal-finance-tracker"
LOG_DIR="/var/log/personal-finance-tracker"
BACKUP_DIR="/var/backups/personal-finance-tracker"

# Enhanced error handling with cleanup
cleanup_on_error() {
    local exit_code=$?
    local line_number=$1
    
    print_error "Deployment failed at line $line_number with exit code $exit_code"
    print_error "Running cleanup procedures..."
    
    # Stop any running services
    pm2 delete personal-finance-tracker 2>/dev/null || true
    
    # Clean up partial installation
    if [ -d "$APP_DIR" ]; then
        print_status "Cleaning up application directory..."
        cd /tmp
        sudo rm -rf "$APP_DIR" 2>/dev/null || true
    fi
    
    # Reset nginx configuration
    sudo rm -f /etc/nginx/sites-enabled/personal-finance-tracker
    sudo rm -f /etc/nginx/sites-available/personal-finance-tracker
    sudo systemctl reload nginx 2>/dev/null || true
    
    print_error "Cleanup completed. Check logs above for the cause of failure."
    exit $exit_code
}

# Set up error handling
trap 'cleanup_on_error $LINENO' ERR

# System requirements check
check_system() {
    print_status "Checking system requirements..."
    
    # Check if running as root
    [[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
    
    # Check sudo access
    command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }
    
    # Check Ubuntu version
    if ! lsb_release -d 2>/dev/null | grep -qi ubuntu; then
        print_warning "Optimized for Ubuntu. Other distributions may work but are not officially supported."
    fi
    
    # Check architecture
    if [ "$(uname -m)" != "x86_64" ]; then
        print_warning "Optimized for x86_64 architecture. Other architectures may encounter issues."
    fi
    
    # Check memory
    total_mem_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    total_mem_mb=$((total_mem_kb / 1024))
    
    if [ "$total_mem_mb" -lt 1024 ]; then
        print_warning "Low memory detected (${total_mem_mb}MB). Recommended: 2GB+ RAM for optimal performance."
    fi
    
    # Check disk space
    available_space_kb=$(df / | awk 'NR==2{print $4}')
    available_space_gb=$((available_space_kb / 1024 / 1024))
    
    if [ "$available_space_gb" -lt 2 ]; then
        print_warning "Low disk space detected (${available_space_gb}GB available). Recommended: 5GB+ free space."
    fi
    
    # Check if required ports are available
    if command -v ss >/dev/null && ss -tuln | grep -q ":5000 "; then
        print_warning "Port 5000 is already in use. This may cause conflicts."
    fi
    
    if command -v ss >/dev/null && ss -tuln | grep -q ":80 "; then
        print_warning "Port 80 is already in use. This may cause conflicts with Nginx."
    fi
    
    print_status "System requirements check completed"
}

# Main deployment function
main() {
    print_status "Starting complete deployment process..."
    check_system

    # Install system dependencies
    print_status "Installing system dependencies..."
    
    # Update package lists
    sudo apt update -y || { print_error "Failed to update package lists"; exit 1; }
    
    # Install essential packages
    sudo apt install -y curl wget gnupg lsb-release software-properties-common || { print_error "Failed to install essential packages"; exit 1; }
    
    # Install PostgreSQL with version checking
    print_status "Installing PostgreSQL..."
    sudo apt install -y postgresql postgresql-contrib || { print_error "Failed to install PostgreSQL"; exit 1; }
    
    # Install Nginx
    print_status "Installing Nginx..."
    sudo apt install -y nginx || { print_error "Failed to install Nginx"; exit 1; }
    
    # Install Certbot for SSL
    print_status "Installing Certbot..."
    sudo apt install -y certbot python3-certbot-nginx || { print_error "Failed to install Certbot"; exit 1; }
    
    # Install build tools
    print_status "Installing build tools..."
    sudo apt install -y build-essential python3 python3-pip || { print_error "Failed to install build tools"; exit 1; }
    
    # Install additional utilities
    sudo apt install -y git htop ufw fail2ban logrotate || print_warning "Some optional packages failed to install"

    # Install Node.js 20
    if ! command -v node &>/dev/null; then
        print_status "Installing Node.js 20..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - || { print_error "Failed to add Node.js repository"; exit 1; }
        sudo apt install -y nodejs || { print_error "Failed to install Node.js"; exit 1; }
    else
        node_version=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
        if [ "$node_version" -lt 18 ]; then
            print_warning "Node.js version is older than 18. Consider upgrading."
        fi
    fi
    
    # Verify Node.js installation
    node --version || { print_error "Node.js installation verification failed"; exit 1; }
    npm --version || { print_error "npm installation verification failed"; exit 1; }
    
    # Install PM2
    if ! command -v pm2 &>/dev/null; then
        print_status "Installing PM2..."
        sudo npm install -g pm2 || { print_error "Failed to install PM2"; exit 1; }
    else
        print_status "PM2 already installed"
    fi
    
    # Start and enable services
    print_status "Starting system services..."
    sudo systemctl enable postgresql || print_warning "Failed to enable PostgreSQL"
    sudo systemctl start postgresql || { print_error "Failed to start PostgreSQL"; exit 1; }
    
    sudo systemctl enable nginx || print_warning "Failed to enable Nginx"
    sudo systemctl start nginx || { print_error "Failed to start Nginx"; exit 1; }
    
    # Configure fail2ban for security
    print_status "Configuring fail2ban..."
    sudo systemctl enable fail2ban || print_warning "Failed to enable fail2ban"
    sudo systemctl start fail2ban || print_warning "Failed to start fail2ban"

    # Setup application
    APP_DIR="/var/www/personal-finance-tracker"
    print_status "Setting up application..."
    
    # Create app directory and set permissions
    sudo mkdir -p $APP_DIR || { print_error "Failed to create application directory"; exit 1; }
    sudo chown $USER:$USER $APP_DIR || { print_error "Failed to set directory permissions"; exit 1; }
    
    # Copy files to application directory
    print_status "Copying application files..."
    cp -r . $APP_DIR/ || { print_error "Failed to copy application files"; exit 1; }
    cd $APP_DIR || { print_error "Failed to change to application directory"; exit 1; }

    # Generate secure credentials
    print_status "Generating secure credentials..."
    DB_PASSWORD=$(openssl rand -base64 32)
    SESSION_SECRET=$(openssl rand -hex 32)
    
    # Create database and user
    print_status "Setting up PostgreSQL database..."
    sudo -u postgres psql << EOF || { print_error "Failed to setup PostgreSQL database"; exit 1; }
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
\q
EOF

    # Create environment file
    print_status "Creating environment configuration..."
    cat > .env << ENV || { print_error "Failed to create environment file"; exit 1; }
DATABASE_URL=postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
ENV

    # Install dependencies 
    print_status "Installing dependencies..."
    npm install || { print_error "Failed to install dependencies"; exit 1; }

    # Setup database schema
    print_status "Initializing database..."
    
    # URL encode the password to handle special characters
    if command -v python3 >/dev/null 2>&1; then
        DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
    else
        print_warning "Python3 not available, using password as-is (may cause issues with special characters)"
        DB_PASSWORD_ENCODED="$DB_PASSWORD"
    fi
    export DATABASE_URL="postgresql://finance_user:$DB_PASSWORD_ENCODED@localhost:5432/personal_finance_db"
    export SESSION_SECRET
    export NODE_ENV=production
    
    # Test database connection first
    print_status "Testing database connection..."
    if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
        print_error "Database connection failed. Check PostgreSQL setup."
        exit 1
    fi
    
    print_status "Pushing database schema..."
    # Try with encoded URL first, then fallback to direct connection
    if ! npm run db:push 2>&1; then
        print_warning "Schema push with encoded URL failed, trying direct connection..."
        export DATABASE_URL="postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db"
        if ! npm run db:push 2>&1; then
            print_error "Database schema push failed with both URL formats."
            exit 1
        fi
    fi
    
    # Update .env file with working DATABASE_URL
    print_status "Updating environment configuration with working database URL..."
    cat > .env << ENV || { print_error "Failed to update environment file"; exit 1; }
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
ENV

    # Build application with extended timeout and memory optimization
    print_status "Building application..."
    export NODE_OPTIONS="--max-old-space-size=4096"
    if ! timeout 600 npm run build 2>&1; then
        print_warning "Build timed out or failed, trying fallback strategy..."
        # Fallback strategy for resource-constrained VPS
        export NODE_OPTIONS="--max-old-space-size=2048"
        if ! timeout 300 npm run build 2>&1; then
            print_error "Build failed even with fallback strategy. Check available memory and try building locally."
            exit 1
        fi
    fi

    # Create PM2 configuration
    print_status "Creating PM2 configuration..."
    cat > ecosystem.config.cjs << 'EOF' || { print_error "Failed to create PM2 configuration"; exit 1; }
module.exports = {
  apps: [{
    name: 'personal-finance-tracker',
    script: 'dist/index.js',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/personal-finance-tracker/error.log',
    out_file: '/var/log/personal-finance-tracker/out.log',
    log_file: '/var/log/personal-finance-tracker/combined.log',
    time: true,
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024'
  }]
}
EOF

    # Configure PM2 and services
    print_status "Configuring services..."
    sudo mkdir -p /var/log/personal-finance-tracker || { print_error "Failed to create log directory"; exit 1; }
    sudo chown $USER:$USER /var/log/personal-finance-tracker || { print_error "Failed to set log directory permissions"; exit 1; }
    
    # Export environment variables for PM2
    export DATABASE_URL
    export SESSION_SECRET
    export NODE_ENV=production
    export PORT=5000
    export PGHOST=localhost
    export PGPORT=5432
    export PGUSER=finance_user
    export PGPASSWORD="$DB_PASSWORD"
    export PGDATABASE=personal_finance_db

# Configure Nginx
sudo tee /etc/nginx/sites-available/personal-finance-tracker > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

sudo ln -sf /etc/nginx/sites-available/personal-finance-tracker /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs personal-finance-tracker"
    exit 1
fi

# Setup security and firewall
print_status "Configuring security..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Create management script
print_status "Creating management script..."
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/personal-finance-tracker"
APP_DIR="/var/www/personal-finance-tracker"

backup_database() {
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    echo "Creating database backup..."
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$PGPASSWORD" ]; then
        # Extract password from DATABASE_URL if PGPASSWORD not set
        PGPASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U finance_user personal_finance_db > $BACKUP_FILE; then
        echo "✓ Backup saved to: $BACKUP_FILE"
        # Keep only last 7 backups
        ls -t $BACKUP_DIR/backup_*.sql | tail -n +8 | xargs -r rm
        echo "✓ Old backups cleaned up (keeping last 7)"
    else
        echo "✗ Backup failed!"
        exit 1
    fi
}

restore_database() {
    local backup_file=$2
    if [ -z "$backup_file" ]; then
        echo "Available backups:"
        ls -la $BACKUP_DIR/backup_*.sql 2>/dev/null || echo "No backups found"
        echo "Usage: $0 restore /path/to/backup.sql"
        exit 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        echo "✗ Backup file not found: $backup_file"
        exit 1
    fi
    
    echo "⚠️  WARNING: This will replace all current data!"
    echo "Press Enter to continue or Ctrl+C to cancel..."
    read
    
    echo "Stopping application..."
    pm2 stop personal-finance-tracker
    
    echo "Restoring database from: $backup_file"
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$PGPASSWORD" ]; then
        PGPASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" && \
       PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_user personal_finance_db < $backup_file; then
        echo "✓ Database restored successfully"
        pm2 start personal-finance-tracker
        echo "✓ Application restarted"
    else
        echo "✗ Restore failed!"
        pm2 start personal-finance-tracker
        exit 1
    fi
}

safe_update() {
    echo "Starting safe update process..."
    
    # Create pre-update backup
    echo "Creating pre-update backup..."
    backup_database
    
    # Stop application
    echo "Stopping application..."
    pm2 stop personal-finance-tracker
    
    # Update code
    echo "Pulling latest changes..."
    if git pull; then
        echo "✓ Code updated"
    else
        echo "✗ Git pull failed!"
        pm2 start personal-finance-tracker
        exit 1
    fi
    
    # Install dependencies
    echo "Installing dependencies..."
    if npm install; then
        echo "✓ Dependencies updated"
    else
        echo "✗ npm install failed!"
        pm2 start personal-finance-tracker
        exit 1
    fi
    
    # Update database schema
    echo "Updating database schema..."
    if npm run db:push; then
        echo "✓ Database schema updated"
    else
        echo "✗ Database migration failed!"
        echo "Restoring from backup..."
        # Find the most recent backup
        LATEST_BACKUP=$(ls -t $BACKUP_DIR/backup_*.sql | head -1)
        restore_database restore $LATEST_BACKUP
        exit 1
    fi
    
    # Build application
    echo "Building application..."
    export NODE_OPTIONS="--max-old-space-size=4096"
    if timeout 600 npm run build; then
        echo "✓ Application built"
    else
        echo "✗ Build failed!"
        pm2 start personal-finance-tracker
        exit 1
    fi
    
    # Start application
    echo "Starting application..."
    pm2 start personal-finance-tracker
    
    # Verify application is running
    sleep 5
    if pm2 list | grep -q "personal-finance-tracker.*online"; then
        echo "✓ Update completed successfully!"
    else
        echo "✗ Application failed to start after update!"
        echo "Check logs with: pm2 logs personal-finance-tracker"
    fi
}

ssl_setup() {
    local domain=$2
    if [ -z "$domain" ]; then
        echo "Usage: $0 ssl yourdomain.com"
        exit 1
    fi
    
    echo "Setting up SSL certificate for $domain..."
    
    # Update Nginx configuration with domain
    sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/personal-finance-tracker
    sudo systemctl reload nginx
    
    # Get SSL certificate
    if sudo certbot --nginx -d $domain --non-interactive --agree-tos --email admin@$domain; then
        echo "✓ SSL certificate configured successfully"
        echo "✓ Your site is now available at: https://$domain"
    else
        echo "✗ SSL setup failed!"
        echo "Make sure:"
        echo "  1. Domain $domain points to this server's IP"
        echo "  2. Ports 80 and 443 are open"
        echo "  3. Domain has proper DNS records"
    fi
}

case $1 in
    status)
        echo "=== Application Status ==="
        pm2 status
        echo ""
        echo "=== System Resources ==="
        free -h
        df -h
        echo ""
        echo "=== Service Status ==="
        systemctl is-active nginx postgresql
        ;;
    logs)
        pm2 logs personal-finance-tracker
        ;;
    restart)
        pm2 restart personal-finance-tracker
        ;;
    backup)
        backup_database
        ;;
    restore)
        restore_database "$@"
        ;;
    update)
        safe_update
        ;;
    ssl)
        ssl_setup "$@"
        ;;
    *)
        echo "Personal Finance Tracker Management"
        echo "Usage: $0 {status|logs|restart|backup|restore|update|ssl}"
        echo ""
        echo "Commands:"
        echo "  status  - Show application and system status"
        echo "  logs    - Show application logs"
        echo "  restart - Restart the application"
        echo "  backup  - Create database backup"
        echo "  restore - Restore database from backup"
        echo "  update  - Safely update application"
        echo "  ssl     - Setup SSL certificate for domain"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Verify deployment
print_status "Verifying deployment..."
sleep 10

# Check if application is running
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    print_status "✓ Application is running"
else
    print_warning "✗ Application may not be running properly"
    pm2 restart personal-finance-tracker || print_warning "Restart failed"
fi

# Check web server response
if curl -f -s http://localhost >/dev/null 2>&1; then
    print_status "✓ Web server responding"
else
    print_warning "✗ Web server not responding, checking..."
    sudo systemctl restart nginx
    sleep 5
fi

# Final status check
print_status "Final status check..."
./manage.sh status

# Display completion message
echo ""
echo "================================================="
echo "🎉 Deployment Complete!"
echo "================================================="
echo ""

# Get public IP
PUBLIC_IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "YOUR_SERVER_IP")

echo "🌐 Application URL: http://$PUBLIC_IP"
echo "⚠️  SSL: Not configured (use ./manage.sh ssl yourdomain.com)"
echo ""
echo "Management Commands:"
echo "  ./manage.sh status   - Check application status"
echo "  ./manage.sh logs     - View logs"
echo "  ./manage.sh backup   - Create backup"
echo "  ./manage.sh update   - Update application"
echo "  ./manage.sh ssl      - Setup SSL certificate"
echo ""
echo "Database Details:"
echo "  Database: personal_finance_db"
echo "  User: finance_user"
echo "  Password: [stored in .env file]"
echo ""
echo "Log Files:"
echo "  Application: /var/log/personal-finance-tracker/"
echo "  Nginx: /var/log/nginx/"
echo "  PostgreSQL: /var/log/postgresql/"
echo ""
    print_status "Deployment completed successfully!"
}

# Execute main function with all arguments
main "$@"