#!/bin/bash

# Quick fix for authentication issues on VPS
# Run this script on your VPS to fix the session authentication

set -e

echo "======================================"
echo "Personal Finance Tracker - Auth Fix"
echo "======================================"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "Please run this script from the application directory (/var/www/personal-finance-tracker)"
    exit 1
fi

print_status "Stopping application..."
pm2 stop personal-finance-tracker 2>/dev/null || true

print_status "Updating session configuration..."

# Update server/index.ts with fixed session configuration
cat > server/index.ts << 'EOF'
import express, { type Request, Response, NextFunction } from "express";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

// Extend session data type
declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Session middleware with PostgreSQL store
const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
const pgStore = connectPg(session);
const sessionStore = new pgStore({
  conString: process.env.DATABASE_URL,
  createTableIfMissing: true,
  ttl: sessionTtl,
  tableName: "sessions",
});

app.use(session({
  secret: process.env.SESSION_SECRET || 'fallback-secret-for-dev',
  store: sessionStore,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // Set to false for HTTP, true only when HTTPS is properly configured
    httpOnly: true,
    maxAge: sessionTtl,
    sameSite: 'lax'
  }
}));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      log(logLine);
    }
  });

  next();
});

app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  res.status(status).json({ message });
  throw err;
});

const server = registerRoutes(app);

if (process.env.NODE_ENV !== "production") {
  setupVite(app, server);
} else {
  serveStatic(app);
}

const PORT = Number(process.env.PORT) || 5000;
server.listen(PORT, "0.0.0.0", () => {
  log(`serving on port ${PORT}`);
});
EOF

print_status "Rebuilding application..."
npm run build

print_status "Restarting application..."
pm2 start personal-finance-tracker

print_status "Waiting for application to start..."
sleep 5

# Check if application is running
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    print_status "✓ Application restarted successfully!"
    print_status "✓ Session authentication should now work properly"
    print_status ""
    print_status "Please try logging in again. The session issues should be resolved."
else
    print_error "✗ Application failed to start!"
    print_status "Check logs with: pm2 logs personal-finance-tracker"
    exit 1
fi

print_status "Authentication fix completed!"
EOF