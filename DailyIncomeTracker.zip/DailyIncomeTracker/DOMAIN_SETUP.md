# Domain Setup Guide for finance.zaihash.xyz

## Overview
This guide will help you deploy your Personal Finance Tracker application to your subdomain `finance.zaihash.xyz` on your VPS.

## Prerequisites
- Ubuntu 20.04+ VPS with root/sudo access
- Domain `zaihash.xyz` already pointing to your server
- At least 2GB RAM recommended
- Ports 80, 443, and 22 open in firewall

## DNS Configuration

### Step 1: Add Subdomain DNS Record
In your domain registrar's DNS settings, add:
```
Type: A
Name: finance
Value: YOUR_SERVER_IP
TTL: 300 (or default)
```

Or if using a CNAME:
```
Type: CNAME
Name: finance
Value: zaihash.xyz
TTL: 300
```

### Step 2: Verify DNS Propagation
```bash
# Check if subdomain resolves correctly
dig finance.zaihash.xyz

# Should return your server's IP address
```

## Deployment Options

### Option 1: One-Click Deployment (Recommended)
Upload the project files to your server and run:
```bash
# Make the script executable
chmod +x deploy-subdomain.sh

# Run the deployment script
./deploy-subdomain.sh
```

This script will:
- Install Node.js 20, PostgreSQL, Nginx, PM2
- Configure the database
- Set up the application
- Configure Nginx for your subdomain
- Install SSL certificate automatically
- Create management scripts

### Option 2: Manual Deployment
If you prefer manual setup, follow these steps:

1. **Install Dependencies**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Install Nginx
sudo apt install -y nginx

# Install PM2
sudo npm install -g pm2
```

2. **Setup Database**
```bash
# Create database and user
sudo -u postgres psql
CREATE USER finance_user WITH ENCRYPTED PASSWORD 'your_secure_password';
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
\q
```

3. **Deploy Application**
```bash
# Create application directory
sudo mkdir -p /var/www/personal-finance-tracker
sudo chown $USER:$USER /var/www/personal-finance-tracker

# Copy files to server
scp -r * user@your-server:/var/www/personal-finance-tracker/

# Install dependencies and build
cd /var/www/personal-finance-tracker
npm install
npm run build
```

4. **Configure Environment**
Create `.env` file:
```env
DATABASE_URL=postgresql://finance_user:your_password@localhost:5432/personal_finance_db
SESSION_SECRET=your_session_secret
NODE_ENV=production
PORT=5000
```

5. **Setup Database Schema**
```bash
npm run db:push
```

6. **Configure Nginx**
Create `/etc/nginx/sites-available/personal-finance-tracker`:
```nginx
server {
    listen 80;
    server_name finance.zaihash.xyz;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/personal-finance-tracker /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

7. **Start Application**
```bash
# Start with PM2
pm2 start npm --name "personal-finance-tracker" -- run start
pm2 save
pm2 startup
```

8. **Setup SSL**
```bash
# Install Certbot
sudo snap install --classic certbot

# Get SSL certificate
sudo certbot --nginx -d finance.zaihash.xyz
```

## Port Configuration
- **Main Site**: Your existing site on zaihash.xyz (port 80/443)
- **Finance App**: Runs on port 3001 (internal, proxied through Nginx)
- **Nginx**: Listens on port 80 (HTTP) and 443 (HTTPS) for both domains
- **Database**: PostgreSQL on port 5432 (local only)

### No Port Conflicts
The setup is designed to avoid conflicts:
- Your main site (zaihash.xyz) continues running as before
- Finance app runs on internal port 3001
- Nginx handles routing based on domain name
- Both sites share ports 80/443 through virtual hosts

## Management Commands
After deployment, use these commands to manage your application:

```bash
# Check status
./manage.sh status

# View logs
./manage.sh logs

# Restart application
./manage.sh restart

# Update application
./manage.sh update

# Create database backup
./manage.sh backup

# Renew SSL certificate
./manage.sh ssl-renew
```

## Troubleshooting

### Common Issues

1. **Domain not resolving**
   - Check DNS propagation: `dig finance.zaihash.xyz`
   - Wait for DNS to propagate (can take up to 24 hours)

2. **Application not starting**
   - Check logs: `pm2 logs personal-finance-tracker`
   - Verify database connection: `psql -U finance_user -d personal_finance_db`

3. **SSL issues**
   - Ensure domain points to server before running Certbot
   - Check firewall allows ports 80 and 443

4. **502 Bad Gateway**
   - Application not running: `pm2 restart personal-finance-tracker`
   - Check if port 5000 is available: `netstat -tlnp | grep 5000`

### Logs Location
- Application logs: `/var/log/personal-finance-tracker/`
- Nginx logs: `/var/log/nginx/`
- PostgreSQL logs: `/var/log/postgresql/`

## Security Notes
- Database is configured for local access only
- Firewall configured to allow only necessary ports
- SSL certificate automatically renewed
- Security headers configured in Nginx

## Support
If you encounter issues:
1. Check the logs using the management commands
2. Verify all services are running: `systemctl status nginx postgresql`
3. Ensure DNS is properly configured
4. Check firewall settings: `sudo ufw status`

Your Personal Finance Tracker will be available at: https://finance.zaihash.xyz