#!/bin/bash

# Personal Finance Tracker - Simple Deployment Script
# Domain: finance.zaihash.xyz
# Manual SSL setup (no automatic SSL configuration)

set -e

DOMAIN="finance.zaihash.xyz"
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
LOG_DIR="/var/log/$APP_NAME"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "This script should not be run as root. Please run as a regular user with sudo privileges."
   exit 1
fi

# Check for port conflicts
print_status "Checking for port conflicts..."
if command -v ss >/dev/null 2>&1; then
    if sudo ss -tlnp | grep -q ":3001 "; then
        print_warning "Port 3001 is already in use. Using port 3002 instead."
        APP_PORT=3002
    else
        APP_PORT=3001
    fi
else
    APP_PORT=3001
fi

print_status "Application will run on port $APP_PORT"

# Update system
print_status "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install required packages
print_status "Installing required packages..."
sudo apt install -y curl wget gnupg2 software-properties-common apt-transport-https ca-certificates lsb-release

# Install Node.js 20
print_status "Installing Node.js 20..."
if ! command -v node >/dev/null 2>&1; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    print_status "Node.js already installed"
fi

# Install PostgreSQL
print_status "Installing PostgreSQL..."
if ! command -v psql >/dev/null 2>&1; then
    sudo apt install -y postgresql postgresql-contrib
else
    print_status "PostgreSQL already installed"
fi

# Install Nginx
print_status "Installing Nginx..."
if ! command -v nginx >/dev/null 2>&1; then
    sudo apt install -y nginx
else
    print_status "Nginx already installed"
fi

# Install PM2
print_status "Installing PM2..."
if ! command -v pm2 >/dev/null 2>&1; then
    sudo npm install -g pm2
else
    print_status "PM2 already installed"
fi

# Setup PostgreSQL database
print_status "Setting up PostgreSQL database..."
DB_PASSWORD=$(openssl rand -base64 32)
sudo -u postgres psql << EOF || print_warning "Database setup might have failed - continuing anyway"
CREATE USER finance_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
ALTER USER finance_user CREATEDB;
\q
EOF

# Create application directory
print_status "Creating application directory..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Create log directory
print_status "Creating log directory..."
sudo mkdir -p $LOG_DIR
sudo chown $USER:$USER $LOG_DIR

# Copy application files
print_status "Copying application files..."
cp -r * $APP_DIR/
cd $APP_DIR

# Create environment file
print_status "Creating environment configuration..."
cat > .env << EOF
DATABASE_URL=postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db
SESSION_SECRET=$(openssl rand -base64 32)
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
EOF

# Install dependencies
print_status "Installing application dependencies..."
npm install

# Build application
print_status "Building application..."
npm run build

# Push database schema
print_status "Setting up database schema..."
npm run db:push

# Create PM2 ecosystem file
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [
    {
      name: '$APP_NAME',
      script: 'npm',
      args: 'run start',
      cwd: '$APP_DIR',
      env: {
        NODE_ENV: 'production',
        PORT: $APP_PORT
      },
      env_file: '.env',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      error_file: '$LOG_DIR/error.log',
      out_file: '$LOG_DIR/out.log',
      log_file: '$LOG_DIR/combined.log',
      time: true
    }
  ]
};
EOF

# Configure Nginx
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOF
server {
    listen 80;
    server_name $DOMAIN;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    add_header Content-Security-Policy "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; connect-src 'self' ws: wss:;";
}
EOF

# Enable Nginx site
sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# Start application with PM2
print_status "Starting application..."
pm2 delete $APP_NAME 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 auto-startup
print_status "Setting up PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME

# Configure firewall
print_status "Configuring firewall..."
sudo ufw --force enable
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'

# Create management script
print_status "Creating management script..."
cat > manage.sh << 'SCRIPT'
#!/bin/bash

APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
LOG_DIR="/var/log/$APP_NAME"

case $1 in
    status)
        echo "=== Application Status ==="
        pm2 status
        echo ""
        echo "=== System Resources ==="
        free -h
        df -h
        echo ""
        echo "=== Service Status ==="
        systemctl is-active nginx postgresql
        ;;
    logs)
        pm2 logs $APP_NAME
        ;;
    restart)
        pm2 restart $APP_NAME
        ;;
    update)
        echo "Updating application..."
        cd $APP_DIR
        npm install
        npm run build
        npm run db:push
        pm2 restart $APP_NAME
        echo "Application updated successfully!"
        ;;
    backup)
        echo "Creating database backup..."
        sudo -u postgres pg_dump personal_finance_db > "backup-$(date +%Y%m%d-%H%M%S).sql"
        echo "Backup created successfully!"
        ;;
    *)
        echo "Personal Finance Tracker Management"
        echo "Usage: $0 {status|logs|restart|update|backup}"
        echo ""
        echo "Commands:"
        echo "  status     - Show application and system status"
        echo "  logs       - Show application logs"
        echo "  restart    - Restart the application"
        echo "  update     - Update application"
        echo "  backup     - Create database backup"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Verify deployment
print_status "Verifying deployment..."
sleep 5

if pm2 list | grep -q "$APP_NAME.*online"; then
    print_status "Application is running successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs $APP_NAME"
    exit 1
fi

# Final status
print_status "Deployment completed successfully!"
echo ""
echo "================================================="
echo "🎉 Personal Finance Tracker Deployed!"
echo "================================================="
echo ""
echo "🌐 Application URL: http://$DOMAIN"
echo "🔒 SSL: Manual setup required"
echo "📱 Port: $APP_PORT (internal)"
echo ""
echo "Next Steps:"
echo "1. Set up SSL certificate manually:"
echo "   sudo apt install certbot python3-certbot-nginx"
echo "   sudo certbot --nginx -d $DOMAIN"
echo ""
echo "Management Commands:"
echo "  ./manage.sh status     - Check application status"
echo "  ./manage.sh logs       - View application logs"
echo "  ./manage.sh restart    - Restart application"
echo "  ./manage.sh update     - Update application"
echo "  ./manage.sh backup     - Create database backup"
echo ""
echo "Application Details:"
echo "  Domain: $DOMAIN"
echo "  Internal Port: $APP_PORT"
echo "  Directory: $APP_DIR"
echo "  Database: personal_finance_db"
echo ""
echo "Your Personal Finance Tracker is now live at:"
echo "http://$DOMAIN"
echo ""
echo "To add SSL, run: sudo certbot --nginx -d $DOMAIN"
echo ""